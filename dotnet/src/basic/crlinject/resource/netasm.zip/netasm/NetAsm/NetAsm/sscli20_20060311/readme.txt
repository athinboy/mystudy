Files extracted from SSCLI20_20060311 http://www.microsoft.com/downloads/details.aspx?FamilyId=8C09FD61-3F26-4555-AE17-3121B4F51D4D&displaylang=en 
clr\src\inc\CorHdr.h
clr\src\inc\corinfo.h
clr\src\inc\corjit.h